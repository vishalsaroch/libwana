import MyReviews from "@/components/PagesComponent/Reviews/Reviews"


const ReviewsPage = () => {
    return (
        <MyReviews />
    )
}

export default ReviewsPage