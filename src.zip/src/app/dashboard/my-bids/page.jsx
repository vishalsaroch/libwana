'use client'
import React from 'react'
import MyBids from '@/components/PagesComponent/Dashboard/MyBids'

export default function MyBidsPage() {
  return (
    <div className="container">
      <MyBids />
    </div>
  )
}
